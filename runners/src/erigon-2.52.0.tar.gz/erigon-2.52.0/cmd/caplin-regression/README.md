# Caplin Regression

Tool to test for regressions in Caplin's components