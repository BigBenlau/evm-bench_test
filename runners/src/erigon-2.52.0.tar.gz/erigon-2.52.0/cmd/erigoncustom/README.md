
# Erigon Custom

This is an example of an app based on Erigon library that adds a custom
step to the [StagedSync](../../eth/stagedsync) and adds a custom command line
flag.
