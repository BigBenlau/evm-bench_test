---
name: Report a bug
about: Something with Erigon is not working as expected
title: ''
labels: 'type:bug'
assignees: ''
---

#### System information

Erigon version: `./erigon --version`

OS & Version: Windows/Linux/OSX

Commit hash: 

Erigon Command (with flags/config):

Concensus Layer:

Concensus Layer Command (with flags/config):

Chain/Network: 

#### Expected behaviour


#### Actual behaviour


#### Steps to reproduce the behaviour


#### Backtrace

````
[backtrace]
````
