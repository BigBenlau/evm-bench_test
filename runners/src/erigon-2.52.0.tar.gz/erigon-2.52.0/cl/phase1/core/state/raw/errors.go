package raw

import "errors"

var (
	// Error for missing validator
	ErrInvalidValidatorIndex = errors.New("invalid validator index")
)
