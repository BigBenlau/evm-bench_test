package merkle_tree

func init() {
	globalHasher = newMerkleHasher()
}
